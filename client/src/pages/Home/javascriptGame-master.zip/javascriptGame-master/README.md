﻿# javascriptGame

﻿5/27/2016: Deleted extraneous .js files

﻿To play the game, download this repository as a .zip file, and click protectron.html under the src folder. Use the left and right arrow keys to steer the ship, and the up arrow key to apply thrust in the desired direction. Refresh the page to try again. The goal of the game is to pick up as many hamburgers as possible without crashing into Earth or Mars.
